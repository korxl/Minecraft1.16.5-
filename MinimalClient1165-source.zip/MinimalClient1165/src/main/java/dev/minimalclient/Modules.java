package dev.minimalclient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.Minecraft;

public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();
    public static final Module XRAY = new Module("Xray (visual stub)");
    public static final Module FULLBRIGHT = new Module("Fullbright") {
        private double oldGamma = 1.0;
        @Override protected void onToggle(boolean value) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options == null) return;
            if (value) { oldGamma = mc.options.gamma; mc.options.gamma = 16.0; }
            else mc.options.gamma = oldGamma;
        }
    };
    public static final Module ESP = new Module("ESP (visual stub)");
    public static final Module KEYSTROKES = new Module("Keystrokes");
    public static final Module TRIGGERBOT = new Module("TriggerBot (test stub)");
    public static final Module AUTOCLICKER = new Module("AutoClicker (test stub)");
    public static final Module KILLAURA = new Module("KillAura (test stub)");
    private Modules() { }
    public static void init() { Collections.addAll(ALL, XRAY, FULLBRIGHT, ESP, KEYSTROKES, TRIGGERBOT, AUTOCLICKER, KILLAURA); }
    public static void tick() { for (Module m : ALL) if (m.isEnabled()) m.tick(); }
}
