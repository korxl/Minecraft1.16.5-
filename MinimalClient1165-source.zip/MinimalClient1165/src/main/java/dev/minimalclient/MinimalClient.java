package dev.minimalclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod("minimalclient")
public class MinimalClient {
    public static final String MODID = "minimalclient";
    private static KeyBinding menuKey;
    private static boolean menuOpen = false;
    public MinimalClient() {
        MinecraftForge.EVENT_BUS.register(this);
        menuKey = new KeyBinding("key.minimalclient.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.misc");
        ClientRegistry.registerKeyBinding(menuKey);
        Modules.init();
    }
    @SubscribeEvent public void onKey(InputEvent.KeyInputEvent event) {
        if (menuKey != null && menuKey.isDown()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.currentScreen == null) mc.displayGuiScreen(new ClickGuiScreen());
        }
    }
    @SubscribeEvent public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Modules.tick();
    }
}
