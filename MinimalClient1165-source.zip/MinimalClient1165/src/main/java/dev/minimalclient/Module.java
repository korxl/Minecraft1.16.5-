package dev.minimalclient;

public class Module {
    public final String name;
    private boolean enabled;
    public Module(String name) { this.name = name; }
    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean value) { if (enabled != value) { enabled = value; onToggle(value); } }
    public void toggle() { setEnabled(!enabled); }
    protected void onToggle(boolean value) { }
    public void tick() { }
}
