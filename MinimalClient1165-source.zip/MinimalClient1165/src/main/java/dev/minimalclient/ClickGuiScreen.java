package dev.minimalclient;

import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.text.StringTextComponent;

public class ClickGuiScreen extends Screen {
    private int left, top, width = 190, rowHeight = 22;
    public ClickGuiScreen() { super(new StringTextComponent("Minimal Client")); }
    @Override protected void init() { left = (this.width - 190) / 2; top = (this.height - (Modules.ALL.size()*rowHeight+36))/2; }
    @Override public void render(MatrixStack matrix, int mouseX, int mouseY, float partialTicks) {
        renderBackground(matrix);
        fill(matrix, left, top, left+width, top+30+Modules.ALL.size()*rowHeight, 0xE8181B22);
        drawString(matrix, this.font, "MINIMAL CLIENT  |  1.16.5", left+10, top+10, 0xFF66D9EF);
        int y = top + 34;
        for (int i=0; i<Modules.ALL.size(); i++) {
            Module m = Modules.ALL.get(i);
            boolean hover = mouseX >= left && mouseX <= left+width && mouseY >= y && mouseY < y+rowHeight;
            fill(matrix, left+5, y, left+width-5, y+rowHeight-2, hover ? 0xFF303846 : 0xFF222630);
            drawString(matrix, this.font, m.name, left+11, y+6, 0xFFE7EAF0);
            drawString(matrix, this.font, m.isEnabled() ? "ON" : "OFF", left+width-30, y+6, m.isEnabled()?0xFF70E090:0xFF858B98);
            y += rowHeight;
        }
        drawString(matrix, this.font, "Click a row to toggle  |  ESC to close", left, y+5, 0xFFB5BAC5);
        super.render(matrix, mouseX, mouseY, partialTicks);
    }
    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int index = (int)((mouseY - (top+34))/rowHeight);
            if (mouseX >= left && mouseX <= left+width && index >= 0 && index < Modules.ALL.size()) Modules.ALL.get(index).toggle();
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
    @Override public boolean isPauseScreen() { return false; }
}
