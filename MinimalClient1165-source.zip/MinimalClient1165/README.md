# Minimal Client — Forge 1.16.5

A small client-side Forge mod project with a minimalist ClickGUI. This is a **starter project**, not a finished competitive cheat. Fullbright and the GUI toggle framework are implemented; Xray, ESP, Keystrokes HUD, TriggerBot, AutoClicker and KillAura are named placeholders and do not perform their advertised features yet.

## Requirements
- 64-bit Java 8 JDK (Forge 1.16.5 toolchain)
- Internet connection for Gradle to download dependencies
- Minecraft Forge 1.16.5, recommended `36.2.39`

## Build the JAR
1. Extract the ZIP.
2. Open a terminal in this folder.
3. On Windows run `gradlew.bat build` if you have added the Gradle wrapper, or use an installed compatible Gradle with `gradle build`.
4. The output JAR is in `build/libs/`.
5. Copy the JAR into `.minecraft/mods/` and launch the Forge 1.16.5 profile.

This source archive intentionally does not include a Gradle wrapper or compiled JAR. If Gradle/ForgeGradle fails with a newer Gradle/JDK, use the official Forge 1.16.5 MDK and its bundled wrapper, then copy these project files into that MDK.

## Controls
- Right Shift: open the menu
- Click a row: toggle a module
- Escape: close the menu

## Notes
- Test in a local single-player world first.
- Server rules and anti-cheat policies vary. This project makes no claim of bypassing anti-cheat.
